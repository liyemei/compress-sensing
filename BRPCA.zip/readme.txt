The Bayesian Principle Component Analysis(BRPCA) codes implemented by MatLab 7.0 are included in this package.

This package includes 4 folders. Folder 'toydata' contains core code and demo of the original BRPCA Model; Folder 'MarkovDependency' contains core code and demos of the modified BRPCA Model with Markov dependency employed; Folder 'NonstationaryNoise' contains core code and demos of the modified BRPCA Model with Markov dependency employed and the noise variances are different from contuguous frames. Folder 'Videodata' contains the video data used by the experiment.

-----------
Files in 'toydata' folder:

Demo_toydata.m:  Demo of the original BRPCA Model for toydata
InitialPara_random.m: returning the initialized parameters of the model
Bayesian_RPCAmcmc.m: returning the collection mean and standard deviation of the Lowrank and Sparse Component, the rank of the Lowrank Component, the number of the Sparse Component.


------------
Files in 'MarkovDependency' folder:

Demo_realdata.m: Demo of the modified BRPCA Model with Markov dependency employed
InitialPara_random_MarkovDep.m: returning the initialized parameters of the modified model
Bayesian_RPCAmcmc_MarkovDep.m: returning the collection mean of the Lowrank and Sparse Component, estimation of the noise precision, the rank of the lowrank component.
realdataDisplay.m:  Display the Lowrank and Sparse Component of the video.



-------------
Files in 'NonstationaryNoise' folder:

Demo_realdata1.m: Demo of the modified BRPCA Model with Markov dependency employed and the noise variances are different from contuguous frames.
InitialPara_random_MarkovDep_NN.m: returning the initialized parameters of the modified model
Bayesian_RPCAmcmc_MarkovDep_NN.m: returning the collection mean of the Lowrank and Sparse Component, estimation of the noise precision, the rank of the lowrank component.
realdataDisplay.m:  Display the Lowrank and Sparse Component of the video and the estimation of noise standard deviation 


-------------
Files in 'Videodata' folder:
WalkByShop1cor0_15_2359.mat: The video data for the experiment. The video was downloaded at http://homepages.inf.ed.ac.uk/rbf/CAVIARDATA1
The data WalkByShop1cor0_15_2359.mat is got by downsample the original video. The downsample factor is 15. 



------------------------------
Xinghao Ding and Lihan He, ECE, Duke University
Created: Aug. 10, 2010
------------------------------