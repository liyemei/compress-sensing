%Demo for Bayesian_RPCAmcmc for toydata. This is the original Model of BRPCA.

%--------------------------------------------------------------------------
% References:
% X. Ding, L. He, and L. Carin, Bayesian Robust Principal Component Analysis, submitted to IEEE Trans. Image Processing (2010)  
%
% Xinghao Ding, Lihan He, ECE, Duke University
% Created: Apr. 12, 2010,
% Last change: Aug. 6, 2010. 
%--------------------------------------------------------------------------




%Generate the toydata------------------------------------------------------
    clc; clear; 
    rand('seed',6);
    randn('seed',6);
    rank_ratio = 0.05;
    SparseDataRatio = 0.05;    
    p = 100;
    n = p;    
    k0 = rank_ratio*p
    A1 =  randn(p,k0); 
    LowrankCom = A1*randn(k0,n); % Lowrank component of the toydata.
    
    Num1 = SparseDataRatio*p*p;
    SampleMatrix = zeros(p,n);
    SampleIndex = randperm(numel(LowrankCom));
    SampleMatrix(SampleIndex(1: fix(SparseDataRatio*numel(LowrankCom)))) = true; %Binary matrix indicating which pixel values are observed
    t0 = -500+1000*rand(p,n);
    SparseCom = t0.*SampleMatrix;% Sparse component of the toydata.
    
    X1 = LowrankCom + SparseCom + (1e-3)*randn(p,n); %Generate the toydata by superposition of the lowrank component, sparse component and noise 
    
    
    
%Initialize model parameters-----------------------------------------------
    Theta0 = InitialPara_random(X1,k0*3); % .
    
    
%Call main function: Bayesian_RPCAmcmc-------------------------------------
    Output = Bayesian_RPCAmcmc(X1,Theta0);
    
    rank_of_ori = rank(LowrankCom);
    rank_of_estimation = round(Output.rankL_mean);
    rank_err = norm(LowrankCom-Output.Lowrank_mean,'fro')/norm(LowrankCom,'fro');    
    num_of_sparse_ori = length(find(SparseCom~=0));
    num_of_sparse_estimation = round(Output.NumSparse_mean);   
    
    disp(['Rank of Original = ', num2str(rank_of_ori),', Rank of Estimation =' num2str(rank_of_estimation) ' and Rank reconstructed error ' num2str(rank_err)]);
    disp(['Number of Original Sparse Component = ', num2str(num_of_sparse_ori),', Mumber of Reconsturcted Sparse Component =' num2str(num_of_sparse_estimation) ]);

  
    
    
