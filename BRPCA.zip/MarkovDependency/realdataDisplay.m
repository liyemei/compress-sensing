[M,N]= size(Output.Lowrank_mean);
row = 144;
col = 192;
for n =1:N
    Lowrank_reco(:,:,n) = reshape(Output.Lowrank_mean(:,n),[row,col]);
    Sparse_reco(:,:,n) = reshape(Output.Sparse_mean(:,n),[row,col]);
    %img(:,:,n) = reshape(X1(:,n),[row,col]);
end

indx = 10;% random select the frame to be shown
figure,imshow(Lowrank_reco(:,:,indx),[])
figure,imshow(Sparse_reco(:,:,indx),[])
