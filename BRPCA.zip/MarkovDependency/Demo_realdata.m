%Demo for Bayesian_RPCAmcmc_withMarkovDep for video data. This is the modified Model of BRPCA
%with Markov dependency employed.

%--------------------------------------------------------------------------
% References:
% X. Ding, L. He, and L. Carin, Bayesian Robust Principal Component Analysis, submitted to IEEE Trans. Image Processing (2010)  
%
% Xinghao Ding, Lihan He, ECE, Duke University
% Created: Apr. 12, 2010,
% Last change: Aug. 6, 2010.
%--------------------------------------------------------------------------


clc; clear %clear all; %close all; format short;


% Load video data ------------------------------------------------------
addpath ../Videodata
load WalkByShop1cor0_15_2359.mat

%The WalkByShop1cor video sequence was downloaded at http://homepages.inf.ed.ac.uk/rbf/CAVIARDATA1
%The data WalkByShop1cor0_15_2359.mat is got by downsample the original video. The downsample factor is 15. 
X1 = double(X11);
X0 = X1/255;
clear X11

% load trafficvideo.mat,
% %The trafficvideo.mat is a traffic video.
% X1 = double(img);
% X0 = X1/255;
% clear img


sigma = 10; %noise variance
randn('seed',0)
X1 = fix(min(max((X1+sigma*randn(size(X1))),0),255));
X1 =double(X1)/255;


row =144;
col = 192;


%Initialize model parameters-----------------------------------------------

K =20;
Theta0 = InitialPara_random_MarkovDep(X1,K);

[P,N] = size(X1);
hyperpara.a0 = 1/K;
hyperpara.b0 = 1-hyperpara.a0;
hyperpara.c0 = 1e-6;
hyperpara.d0 = 1e-6;
hyperpara.e0 = 1e-6;
hyperpara.f0 = 1e-6;
hyperpara.g0 = 1e-6;
hyperpara.h0 = 1e-6;    
hyperpara.alpha0 = 0.01*N;
hyperpara.beta0 = 0.99*N;
hyperpara.alpha1 = 0.99*N;
hyperpara.beta1 = 0.01*N; 

MCMCpara.nBurnin=500;
MCMCpara.nCollect=100;


% Bayeaisn RPCA with Markov dependency on the sparse term in time and space----------   

Output = Bayesian_RPCAmcmc_MarkovDep(X1,Theta0,row,col,hyperpara,MCMCpara);
realdataDisplay

