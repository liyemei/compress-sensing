%Demo for Bayesian_RPCAmcmc_withMarkovDepandNonstationarynoise for video data. 
%Markov dependency is imposed on the sparse component across frames; Noise
%variances are different from contuguous frames.

%--------------------------------------------------------------------------
% References:
% X. Ding, L. He, and L. Carin, Bayesian Robust Principal Component Analysis, submitted to IEEE Trans. Image Processing (2010)  
%
% Xinghao Ding, Lihan He, ECE, Duke University
% Created: Apr. 12, 2010,
% Last change: Aug. 6, 2010.
%--------------------------------------------------------------------------


clc; clear %clear all; %close all; format short;


% Load video data ------------------------------------------------------
addpath ../Videodata
load WalkByShop1cor0_15_2359.mat
%The WalkByShop1cor video sequence was downloaded at http://homepages.inf.ed.ac.uk/rbf/CAVIARDATA1
%The data WalkByShop1cor0_15_2359.mat is got by downsample the original video. The downsample factor is 15. 
X1 = double(X11);
X0 = X1/255;
clear X11

% load trafficvideo.mat,
% %The trafficvideo.mat is a traffic video.
% X1 = double(img);
% X0 = X1/255;
% clear img


randn('seed',0)
[P,N]=size(X0);
temp1 = linspace(5,15,N); %noise variance
indx = randperm(N);
sigma = temp1(indx);
for n = 1:N 
    X1(:,n) = fix(min(max((X0(:,n)+sigma(n)*randn(size(X0(:,n)))),0),255));
end
X1 =double(X1)/255;


row =144;
col = 192;


%Initialize model parameters-----------------------------------------------

K =20;
Theta0 = InitialPara_random_MarkovDep_NN(X1,K);
hyperpara.a0 = 1/K;
hyperpara.b0 = 1-hyperpara.a0;
hyperpara.c0 = 1e-6;
hyperpara.d0 = 1e-6;
hyperpara.e0 = 1e-6;
hyperpara.f0 = 1e-6;
hyperpara.g0 = 1e-6;
hyperpara.h0 = 1e-6;    
hyperpara.alpha0 = 0.01*N;
hyperpara.beta0 = 0.99*N;
hyperpara.alpha1 = 0.99*N;
hyperpara.beta1 = 0.01*N; 

MCMCpara.nBurnin=500;
MCMCpara.nCollect=100;


% Bayeaisn RPCA considering Markov Dependency of the Sparse Term in Time--------------- 
% and Space. Every frame has different noise variance.

Output = Bayesian_RPCAmcmc_MarkovDep_NN(X1,Theta0,row,col,hyperpara,MCMCpara);
realdataDisplay