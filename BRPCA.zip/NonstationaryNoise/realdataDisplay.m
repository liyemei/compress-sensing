
[M,N]= size(Output.Lowrank_mean);
row = 144;
col = 192;
for n =1:N
    Lowrank_reco(:,:,n) = reshape(Output.Lowrank_mean(:,n),[row,col]);
    Sparse_reco(:,:,n) = reshape(Output.Sparse_mean(:,n),[row,col]);
    %img(:,:,n) = reshape(X1(:,n),[row,col]);
end
indx=10; % random select the frame which is to be shown.
figure,imshow(Lowrank_reco(:,:,10),[])
figure,imshow(Sparse_reco(:,:,10),[])

sigma1 =sqrt(1./Output.Gamma_epsi_mean)*255;
figure,plot(sigma1,'r')
hold on
plot(sigma,'k--')
legend('Estimation','Gound truth')
xlabel('Frame of the video')
ylabel('\sigma')