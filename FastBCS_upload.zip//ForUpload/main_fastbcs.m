% Fast Blind compressed sensing (BCS) implementation
% Using variable splitting method
% Refer to " A variable splitting based algorithm for fast multi-coil blind
% compressed sensing MRI reconstruction", EMBC 2014 for further details
% Author: Sampada Bhave 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;

load data.mat

data_orig=squeeze(rssq(img1,3));  % fully sampled coil combined data

[nx,ny,nc,nd] = size(img1);       % dimensions of the image
%csm=repmat(csm,[1 1 1 nd]);       % coil sensitivities
m=nx*ny;
n=nd;

%%% sampling pattern
acc=8;
samp=samp(:,:,1:nd);
samp=repmat(samp,[1 1 1 nc]);
samp=permute(samp,[1 2 4 3]);
OMEGA = find(samp);

%%% undersampled raw data
y=samp.*fft2(img1);
b=y;

%%% first guess
x_init1=zeros(nx,ny,nd);
for ii=1:nc
    x_init1 = x_init1+sqrt(nx*ny)*ifft2(squeeze(b(:,:,ii,:))).*conj(squeeze(csm(:,:,ii,:)));
end
x_init=reshape(double(x_init1),nx*ny,nd);
RMSE(double(x_init1),double(data_orig))

% r denotes the number of temporal basis functions in the dictionary
r =40;

% The algorithm parameters are all specified in opts.
opts.phi = 'lp' ;  % % choices of  'TV' - TV on U
%              'l1' - l1 norm on U
%              'lp' - lp norm on U
opts.con='Fro'; % choice of contraint 'Fro' - Frobenius norm on V
%                     'Col' - Column norm on V

lambda1=[0.01]; % regularizing parameter

opts.outer =100;% The iterations of the outer loop
opts.inner =70;% The iterations of the inner loop
opts.lambda1=lambda1;
opts.r=r;
opts.n1=nx;
opts.n2=ny;
opts.n3 = nd;
opts.betaX =0.01;
opts.betaU =0.01;
opts.betaV =10;
opts.betaZ =0.01;
opts.p= 0.5;
rmse_un=[];
earrayin=[];
tic

  
if strcmp(opts.phi, 'lp')
    [phi,phit] = def_phi_phit_ID;
    RU = @(z)(sum(abs(z(:)).^opts.p))^(1/opts.p);
end

U=zeros(m,r); % Coefficients    
 
V=rand(r,n);  % Randon initialization for the dictionary V

X=x_init;
Z=zeros(size(img1));
for ii=1:nc
    Z(:,:,ii,:)=squeeze(csm(:,:,ii,:)).*x_init1;
end

% define lagrange multipliers for U,V,X,Z
LamU=zeros(size(U));
LamV=zeros(size(V));
LamX=zeros(size(X));
LamZ=zeros(size(Z));

L=0;
lamU=opts.betaU*opts.lambda1;
U=(opts.betaX*X*V'+LamX*V'+lamU*L-opts.lambda1*LamU)*(opts.betaX*V*V'+lamU*eye(r))^(-1);
earrayin=[];
X_est=reshape(U*V,nx,ny,nd);
for cc=1:nc
    Ax(:,:,cc,:)=squeeze(samp(:,:,cc,:)).*((1/sqrt(nx*ny))*fft2(X_est.*squeeze(csm(:,:,cc,:))));
end
dc = Ax-b; % data consistency
reg_U = sum(abs(U(:)).^opts.p)^(1/opts.p); % l1 norm on the spatial weights
cost = sum(abs(dc(:)).^2) +opts.lambda1*reg_U;
earrayin=[earrayin,cost];

opts.betaZ= 1/max(abs(Z(:)));
opts.betaX= 1/max(abs(X(:)));
opts.betaU= 1/max(abs(U(:)));
opts.betaV= 1/max(abs(V(:)));
conZ=[]; conX=[];reconerr=[];TIME=[];conU=[];


for kk=1:100
    kk
    opts.betaV= 1/max(abs(V(:)));
    for ll=1:100
        
        % Update L subproblem
        tmp = U +1/opts.betaU*LamU;
        L_1 = (abs(tmp)-1/opts.betaU*((abs(tmp)+0.00001).^(opts.p-1)));
        L_1 = L_1.*(L_1>0);
        L_2 = abs(tmp)+(abs(tmp)<1e-12);
        L = L_1.*tmp./L_2;
        L=double(L);
        
        % Update U subproblem
        lamU=opts.betaU*opts.lambda1;
        U=(opts.betaX*X*V'+LamX*V'+lamU*L-opts.lambda1*LamU)*pinv(opts.betaX*(V*V')+lamU*eye(r));
        if isempty(find(isnan(U)))==0
            break;
        end
        
        % Update Q subproblem
        KK=V+1/opts.betaV*LamV;
        if strcmp(opts.con,'Col')
            C=1;
            Q=KK*diag(min(sum(KK.^2).^(-.5),1));
        elseif strcmp(opts.con,'Fro')
            C=r;
            Kfn = sum(sum(KK.^2));
            Q = min(1,sqrt(C/Kfn))*KK;
        end
        
        % Update V subproblem
        V=(opts.betaX*(U'*U)+opts.betaV*eye(r))\(opts.betaX*U'*X+U'*LamX+opts.betaV*Q-LamV);
        if isempty(find(isnan(V)))==0
            break;
        end
        
        % Update X subprolem
        S=csm(:,:,:,1);
        S1=opts.betaX*ones(nx)+opts.betaZ*sum(S.*conj(S),3);
        CtZ=squeeze(sum(Z.*conj(csm),3));
        CtLamZ=squeeze(sum(LamZ.*conj(csm),3));
        X=(opts.betaX*reshape(U*V,nx,ny,nd)-reshape(LamX,nx,ny,nd)+opts.betaZ*CtZ+CtLamZ)./repmat(S1,[1 1 nd]);
        X=reshape(X,nx*ny,nd);
        if isempty(find(isnan(X)))==0
            break;
        end
        conX=[conX,abs(sum(sum((X-U*V).^2)))];
        
        % Update Z subproblem
        CX=zeros(nx,ny,nc,nd,'double');
        for cc=1:nc
            CX(:,:,cc,:)=squeeze(csm(:,:,cc,:)).*reshape(X,nx,ny,nd);
        end
        temp=(1/sqrt(nx*ny))*fft2(opts.betaZ/2*CX-LamZ/2+sqrt(nx*ny)*ifft2(samp.*b));
        for tt=1:nd
            for dd=1:nc
                Z(:,:,dd,tt)=sqrt(nx*ny)*ifft2(temp(:,:,dd,tt)./(samp(:,:,dd,tt)+opts.betaZ/2*ones(nx,ny)));
            end
        end
        if isempty(find(isnan(Z(:))))==0
            break;
        end
        
        conZ=[conZ,abs(sum((Z(:)-CX(:)).^2))];
        
        
        LamV=LamV+opts.betaV*(V-Q);
        LamX=LamX+opts.betaX*(X-U*V);
        LamZ=LamZ+opts.betaZ*(Z-CX);
        
        opts.betaV=opts.betaV*5;
        conV=(sum(sum((V-Q).^2)));
        if ll>1
            if conV<1e-7
                ll
                break;
            end
        end
        
    end
    X_est=reshape(U*V,nx,ny,nd);
    for cc=1:nc
        Ax(:,:,cc,:)=squeeze(samp(:,:,cc,:)).*((1/sqrt(nx*ny))*fft2(X_est.*squeeze(csm(:,:,cc,:))));
    end
    dc = Ax-b; % data consistency
    reg_U = sum(abs(U(:)).^opts.p)^(1/opts.p); % l1 norm on the spatial weights
    cost = sum(abs(dc(:)).^2) +opts.lambda1*reg_U;
    earrayin = [earrayin,cost];
    %err=RMSE(double(X_est),data_orig);
    %reconerr=[reconerr,err];
    TIME=[TIME,toc];
    
    conU=[conU,abs(sum(sum((L-U).^2)))];
    figure(10);
    subplot(2,3,1); imagesc(abs(double(U)));title('Example spatial weight')
    subplot(2,3,2); imagesc(abs(V)); title('Dictionary V');
    subplot(2,3,3); imagesc(abs(double(X_est(:,:,2)))); title('A spatial frame: reconstruction');%reshape(L(:,1),n1,n2,1))); title('L');
    subplot(2,3,6); plot(double(earrayin)); title('Decreasing cost');
    subplot(2,3,5); plot(abs(V(1,:))); title('Example temporal basis: 1');
    subplot(2,3,4); plot(conU);
    pause(0.01);
    if kk>1
        if (abs(earrayin(end)-earrayin(end-1))/abs(earrayin(end))) < 1e-2
            opts.betaU=opts.betaU*100;
        end
        if (abs(earrayin(end)-earrayin(end-1))/abs(earrayin(end))) < 1e-8
            kk
            break;
        end
    end
    
end
U=double(U); V = double(V);
X_est=double(X_est);
[MSE,X_corr] = RMSE(X_est, data_orig);
MSE

%%% parameter map estimation
% S0Maps, t1rhoMaps and t2Maps are maps estimated from fullysampled data

% TE and TSL parameters for parameter map estimation
TEs=10:10:120;TEs=TEs';
TSLs=10:10:120;TSLs=TSLs';


[t1rho_recon,t2_recon,S0_recon]=t1rho_t2MapsCalc_ver2(X_corr.*repmat(mapmask,[1,1,nd]),TSLs,TEs);
[MSE_t1rho, t1rho_recon]=RMSE(t1rho_recon.*mask,t1rhoMaps.*mask);
[MSE_t2, t2_recon]=RMSE(t2_recon.*mask,t2Maps.*mask);
[MSE_S0, S0_recon]=RMSE(S0_recon.*mask,S0Maps.*mask);

figure,colormap(jet);
subplot(2,2,1),imagesc(imrotate(t1rhoMaps.*mask,270), [0 100]); axis image; axis off;  title('T1_rho map original');
subplot(2,2,2),imagesc(imrotate(t1rho_recon,270), [0 100]); axis image; axis off;  title('T1_rho map estimated');
subplot(2,2,3),imagesc(imrotate(t2Maps.*mask,270), [0 120]); axis image; axis off;  title('T2 map original');
subplot(2,2,4),imagesc(imrotate(t2_recon,270), [0 120]); axis image; axis off;  title('T2 map estimated');

