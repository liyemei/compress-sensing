% DISCLAIMER : if you do not know what you are doing 
% do not use this program. Do not use it on a 
% motorized vehicle or any machinery 
% for that matter. Even if you know 
% what you are doing, we absolutely 
% CANNOT be held responsible for your 
% use of this program under ANY circumstances.
% The program is released for programming education
% purposes ONLY i.e. reading the code will allow students
% to understand the flow and the intent of an algorithm.   
% The purpose of this code/program is to further human understanding in 
% basic science.
%
% We do not advocate nor condone the use of this program in 
% any robotic systems nor in the implementation of any hardware.
% If you are thinking about including this software
% in a machinery or some larger software program of any sort, 
% please don't do it, because you are on your own.
 