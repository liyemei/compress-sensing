function A = get_A_random( n,m )
    
    A=sqrt(1/m)*randn(m,n);

end
