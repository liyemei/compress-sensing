% 
% 
% x=0:15;
% n=length(x);
% Ls=n/4;%liczba sekcji
% Lps = 2 * Ls; %Liczba podsekcji
% E = log2(n)-1; %number of steps
% %vect=zeros(1,n); % help vector
% DLs = 4; %d�ugo�� sekcji
% DLps = 2; %d�ugo�� podsekcji
% for i=1:E
% i
%     for j=1:Ls
%     j
%         for k=1+(j-1)*DLs:DLs+(j-1)*DLs
%         x(k)
% 
% 
%         end
% 
%     end
%     Ls=Ls/2;
%     Lps = Ls*2;
%     DLs = DLs*2;
%     DLps = DLps*2;
% end
for i=1:100
if mod(i,2)==0
continue;
else
i
end
end
