The Tree-structured Bayesian compressive sensing (TS-BCS) via variational Bayesian inference implemented by MatLab 7.0 is included in this package.

The inverted signal may be either JPEG2000-based wavelet coefficients or JPEG-based block-DCT coefficients (see the paper) 

---------------------------------

Files included in this package:

cameraman.pgm, indor2.pgm: images used by 2-dimensional examples. 


1) For wavelet representation of inverted signal

TSWCSvb.m: main code of TS-BCS for wavelet coefficients implemented by VB.
WaveRelation2D.m: returning parent-children relationship in a wavelet representation of a 2-d image.
demo_TSWCSvb_2d.m: example of a 2-dimensional image: 128x128 image 'cameraman'
demo_TSWCSvb_2d_small.m: example of a 2-dimensional small image: 32x32 image 'indor2'


2) For block-DCT representation of inverted signal

TSDCTCSvb.m: main code of TS-BCS for block-DCT coefficients implemented by VB.
treeDCT2D: returning parent-children relationship in a block-DCT representation of a 2-d image.
treeIDCT2D: inverse block-DCT to get reconstructed image.
demo_TSDCTCSvb_2d.m: example of a 2-dimensional image: 128x128 image 'cameraman'
demo_TSDCTCSvb_2d_small.m: example of a 2-dimensional small image: 32x32 image 'indor2'

-------------

Note:

(a) Other wavelets instead of Haar can also be used. See readme file in the 'tswcs' package.
(b) The function WaveRelation2D.m, treeDCT2D.m and treeIDCT2D.m are the same functions as those in the 'tswcs' and 'tsdctcs' packages.


------------------------------
Lihan He, ECE, Duke University
Created: Aug. 3, 2009
Last update: Aug. 3, 2009
------------------------------