function [theta, indiLevel, IdxParent, IdxChildren, DCTimage]=treeDCT2D(image, BlockSize)
% treeDCT2D: 2-dimensional block-DCT and parent-children relationship
% USAGE:  [theta, indiLevel, IdxParent, IdxChildren, DCTimage]=treeDCT2D(image, BlockSize)
% INPUT:  image: nR x nC, original image
%         BlockSize: scalar, block size for block-DCT
% OUTPUT: theta: M x 1, transform coefficients, arranged in a certain order.  
%                Within each block, the coefficients are arranged as in the 
%                output of wavedec2 function, and blocks are arranged column-wise.
%                M = nR*nC, total number of pixels in the image.
%         indiLevel: M x 1, indicator of level for each coefficient (zero means DC)   
%         IdxParent: M x 1, parent index. IdxParent(i)=j means the parent of the ith
%                    coefficient is coefficient j. Zero means no parent.
%         IdxChildren: M x Nchildren, children index. IdxChildren(i,:)=[j(1),...,j(Nchildren)]
%                      means the children of the ith coefficient are coefficients, j(1),...,j(Nchildren).  
%                      Zeros represent no children.
%         DCTimage: nR x nC, 2-dimensional DCT coefficients after block-DCT 

%-------------------------------
% Lihan He, ECE, Duke University
% Last change: Mar. 4, 2009
%-------------------------------

% number of levels in tree structure
L=log2(BlockSize);
if L~=round(L)
    error('Block size should be 2^N with an integer N.');
end

% numbers of rows and columns of blocks
[nR, nC]=size(image);
N1=nR/BlockSize;
N2=nC/BlockSize;
if (N1~=round(N1) | N2~=round(N2))
    error('Number of rows and/or columns should be integer times of BlockSize.')
end

% initialization
M=nR*nC;
Mb=BlockSize*BlockSize;
Nchildren=4;
theta=zeros(M,1);
indiLevel=zeros(M,1);
IdxParent=zeros(M,1);
IdxChildren=zeros(M,Nchildren);
DCTimage=zeros(nR, nC);

% Parent-Children relationship and levels
S=[2.^[0,0:L];2.^[0,0:L]]';
tmp_parent=WaveTreeParent2Dsc(zeros(1,Mb), S);
vary_parent=(tmp_parent~=0);
tmp_children=[WaveTreeChildren2Dsc(zeros(1,Mb), S),zeros(Nchildren,3*4^(L-1))];
vary_children=(tmp_children~=0);
tmp_level=WaveTreeLevel2Dsc(zeros(1,Mb), S);

% DCT block by block
pt=0;
for n2=1:N2
    for n1=1:N1
        % DCT
        r_idx=(n1-1)*BlockSize+[1:BlockSize];
        c_idx=(n2-1)*BlockSize+[1:BlockSize];
        WaveImageOut=dct2(image(r_idx,c_idx));
        tmp_coeff=WaveTree2Dto1D(WaveImageOut, S);
        theta(pt+[1:Mb])=tmp_coeff(:);
        % indiLevel
        indiLevel(pt+[1:Mb])=tmp_level(:);
        % IdxParent
        IdxParent(pt+[1:Mb])=tmp_parent(:)+pt*vary_parent(:);
        % IdxChildren
        IdxChildren(pt+[1:Mb],:)=tmp_children'+pt*vary_children';
        % DCTimage
        DCTimage(r_idx,c_idx)=WaveImageOut;
        % update pt
        pt=pt+Mb;
    end
end
        
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function IdxParent=WaveTreeParent2Dsc(C, S)

% Find the parent index for the 2D wavelet-decomposed tree dependence.
% Scaling coefficients are included.
% Call the function WaveTreeParent2D(), copied from \45CSHMT, included below 

% call WaveTreeParent2D function
IdxParent=WaveTreeParent2D(C, S);

% Modify parent index
Mscaling=prod(S(1,:));
IdxParent=[zeros(1, Mscaling), IdxParent];
idx=find(IdxParent~=0);
IdxParent(idx)=IdxParent(idx)+Mscaling;

%----------------------------------------------------------------------

function IdxParent=WaveTreeParent2D(C, S)

% Find the parent index for the 2D wavelet-decomposed tree dependence.
% Consider only the wavelet coefficients, excluding the scaling coefficients.
% see instruction of MATLAB wavedec2 function for definition of C and S.
% IdxParent has the size of wavelet coefficients, which is 3*sum(prod(S(2:end-1,:),2)), 
% with IdxParent(i)=j means the parent of the ith wavelet coefficient is
% the jth wavelet coefficient.

% Decomposition level
S=S(2:end-1,:);
N=size(S,1);

% generate indicator matrix for level 2~N
% eg. if S=[8,8;16,16;32;32]  then
% indi{2}=[ 1 1 9 9 ...57 57
%           1 1 9 9 ...57 57
%           2 2 10 10...58 58
%           2 2 10 10...58 58
%           .................
%           8 8 16 16...64 64
%           8 8 16 16...64 64]
for k=2:N
    temp=reshape([1:prod(S(k-1,:))],S(k-1,:));
    temp1=zeros(S(k,1),S(k-1,2));
    temp1(1:2:end,:)=temp;
    temp1(2:2:end,:)=temp;
    indi{k}=zeros(S(k,:));
    indi{k}(:,1:2:end)=temp1;
    indi{k}(:,2:2:end)=temp1;
end

% initialization
pt_pa=0;    % parent pointer
pt_ch=0;    % children pointer
IdxParent=zeros(1,3*sum(prod(S,2)));

% find parent index
Nch=3*S(1,1)*S(1,2);  % 1 level, no parent
pt_ch=pt_ch+Nch;
%
for k=2:N
    Nch=S(k,1)*S(k,2);
    Npa=S(k-1,1)*S(k-1,2);
    %H band
    IdxParent(pt_ch+[1:Nch])=pt_pa+indi{k}(:)';
    pt_ch=pt_ch+Nch;
    pt_pa=pt_pa+Npa;
    %V band
    IdxParent(pt_ch+[1:Nch])=pt_pa+indi{k}(:)';
    pt_ch=pt_ch+Nch;
    pt_pa=pt_pa+Npa;
    %D band
    IdxParent(pt_ch+[1:Nch])=pt_pa+indi{k}(:)';
    pt_ch=pt_ch+Nch;
    pt_pa=pt_pa+Npa;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function IdxChildren=WaveTreeChildren2Dsc(C, S)

% Find the children index for the 2D wavelet-decomposed tree dependence.
% Scaling coefficients are included.
% Call the function WaveTreeChildren2D(), copied from \45CSHMT, included below 

% call WaveTreeChildren2D function
IdxChildren=WaveTreeChildren2D(C, S);

% Modify children index
Mscaling=prod(S(1,:));
IdxChildren=IdxChildren+Mscaling;
Nchildren=size(IdxChildren,1);
IdxChildren=[zeros(Nchildren, Mscaling), IdxChildren];

%------------------------------------------------------------------------

function IdxChildren=WaveTreeChildren2D(C, S)

% Find the children index for the 2D wavelet-decomposed tree dependence.
% Consider only the wavelet coefficients, excluding the scaling coefficients.
% See instruction of MATLAB wavedec2 function for definition of C and S.
% IdxChildren has the size of 4 x 3*sum(prod(S(2:end-2,:),2)), where 
% 3*sum(prod(S(2:end-2,:),2)) is the number of wavelet coefficients which 
% have childrens (the most detailed coefficients do not have children), 
% and each parent has four children.
% IdxChildren(:,i)=[j1;j2;j3;j4] means the ith wavelet coefficient has four
% childrens, which are coefficient j1,j2,j3 and j4.

% decomposition level
S=S(2:end-1,:);
N=size(S,1);

% generate indicator matrix for level 1~N-1
% eg. if S=[8,8;16,16;32;32]  then
% indi{1}=[ 1  3  ... 237 239
%           2  4  ... 238 240
%           17 19 ... 253 255 
%           18 20 ... 254 256]
for k=1:N-1
    temp=reshape([1:prod(S(k+1,:))],S(k+1,:));
    indi{k}=zeros(4,prod(S(k,:)));
    indi{k}(1,:)=reshape(temp(1:2:end,1:2:end),[1,prod(S(k,:))]);
    indi{k}(2,:)=reshape(temp(2:2:end,1:2:end),[1,prod(S(k,:))]);
    indi{k}(3,:)=reshape(temp(1:2:end,2:2:end),[1,prod(S(k,:))]);
    indi{k}(4,:)=reshape(temp(2:2:end,2:2:end),[1,prod(S(k,:))]);
end

% initialization
pt_pa=0;    % parent pointer
pt_ch=0;    % children pointer
IdxChildren=zeros(4, 3*sum(prod(S(1:N-1,:),2)));

% find children index
Nch=3*S(1,1)*S(1,2);  % 1 level, no parent
pt_ch=pt_ch+Nch;
%
for k=1:N-1
    Npa=S(k,1)*S(k,2);
    Nch=S(k+1,1)*S(k+1,2);
    % H band
    IdxChildren(:,pt_pa+[1:Npa])=pt_ch+indi{k};
    pt_pa=pt_pa+Npa;
    pt_ch=pt_ch+Nch;
    % V band
    IdxChildren(:,pt_pa+[1:Npa])=pt_ch+indi{k};
    pt_pa=pt_pa+Npa;
    pt_ch=pt_ch+Nch;
    % D band
    IdxChildren(:,pt_pa+[1:Npa])=pt_ch+indi{k};
    pt_pa=pt_pa+Npa;
    pt_ch=pt_ch+Nch;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function indiLevel=WaveTreeLevel2Dsc(C, S)

% Indicator of level in tree structure for each coefficient (zero means DC)  
% Scaling function are included.

indiLevel=zeros(size(C));
N=size(S,1)-2;

pt=0;
% Scaling level
Ncoeff=prod(S(1,:));   % number of coefficients 
indiLevel(pt+[1:Ncoeff])=0;
pt=pt+Ncoeff;
% wavelet levels
for k=1:N
    Ncoeff=3*prod(S(k+1,:));   % number of coefficients 
    indiLevel(pt+[1:Ncoeff])=k;
    pt=pt+Ncoeff;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function C=WaveTree2Dto1D(WaveImageOut, S)

% Rearrange the wavelet transformed coefficients from 2D form to 1D form.
% The coefficients are arranged as in the output of wavedec2 function.

% number of levels
N=size(S,1)-2;

C=[];
% scaling coefficients
tmp=WaveImageOut(1:S(1,1),1:S(1,2));
C=[C,tmp(:)'];
% wavelet coefficients
for j=1:N
    rr=S(j+1,1);
    cc=S(j+1,2);
    % H band
    tmp=WaveImageOut(1:rr,cc+1:2*cc);
    C=[C,tmp(:)'];
    % V band
    tmp=WaveImageOut(rr+1:2*rr,1:cc);
    C=[C,tmp(:)'];
    % D band
    tmp=WaveImageOut(rr+1:2*rr,cc+1:2*cc);
    C=[C,tmp(:)'];
end

