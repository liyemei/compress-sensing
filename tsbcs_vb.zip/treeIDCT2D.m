function image = treeIDCT2D(theta, BlockSize, ImageSize)
% treeIDCT2D: 2-dimensional inverse block-DCT
% USAGE:  image = treeIDCT2D(theta, BlockSize, ImageSize)
% INPUT:  theta: M x 1, transform coefficients, arranged in a certain order.  
%                Within each block, the coefficients are arranged as in the 
%                output of wavedec2 function, and blocks are arranged column-wise.
%         BlockSize: scalar, block size for block-DCT
%         ImageSize: 1 x 2 , [nR, nC], numbers of rows and columns of the recovered image
%                    nR*nC=M.
% OUTPUT: image: nR x nC, recovered image after inverse block-DCT

%-------------------------------
% Lihan He, ECE, Duke University
% Last change: Mar. 4, 2009
%-------------------------------

% number of levels in tree structure
L=log2(BlockSize);
if L~=round(L)
    error('Block size should be 2^N with an integer N.');
end

% numbers of rows and columns of blocks
nR=ImageSize(1);
nC=ImageSize(2);
if nR*nC ~=length(theta)
    error('Image size does not match coefficient length.')
end
N1=nR/BlockSize;
N2=nC/BlockSize;
if (N1~=round(N1) | N2~=round(N2))
    error('Number of rows and/or columns should be integer times of BlockSize.')
end

% initialization
Mb=BlockSize*BlockSize;
S=[2.^[0,0:L];2.^[0,0:L]]';
image=zeros(nR, nC);

% inverse DCT block by block
pt=0;
for n2=1:N2
    for n1=1:N1
        r_idx=(n1-1)*BlockSize+[1:BlockSize];
        c_idx=(n2-1)*BlockSize+[1:BlockSize];
        WaveImageOut=WaveTree1Dto2D(theta(pt+[1:Mb])', S);
        image(r_idx,c_idx)=idct2(WaveImageOut);
        pt=pt+Mb;
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function WaveImageOut=WaveTree1Dto2D(C, S)

% Rearrange the wavelet transformed coefficients from 1D form to 2D form.
% The coefficients C are arranged as in the output of wavedec2 function.

% number of levels
N=size(S,1)-2;

% initialization
WaveImageOut=zeros(S(N+2,:));

pt=0;
% scaling coefficients
rr=S(1,1);
cc=S(1,2);
NN=rr*cc;
WaveImageOut(1:rr,1:cc)=reshape(C(pt+[1:NN]),[rr,cc]);
pt=pt+NN;
% wavelet coefficients
for j=1:N
    rr=S(j+1,1);
    cc=S(j+1,2);
    NN=rr*cc;
    % H band
    WaveImageOut(1:rr,cc+1:2*cc)=reshape(C(pt+[1:NN]),[rr,cc]);
    pt=pt+NN;
    % V band
    WaveImageOut(rr+1:2*rr,1:cc)=reshape(C(pt+[1:NN]),[rr,cc]);
    pt=pt+NN;
    % D band
    WaveImageOut(rr+1:2*rr,cc+1:2*cc)=reshape(C(pt+[1:NN]),[rr,cc]);
    pt=pt+NN;
end

