% Demo for TSDCTCSmcmc on 2-dimensional 128 x 128 signal
% Source for the original image "cameraman": http://decsai.ugr.es/cvg/dbimagenes/
% Lihan He, Aug. 4, 2009

%----------------
% Generate signal
%----------------

% Load original image -- image0
% image0: original 2-d image, cut from "cameraman" with rows 21:148 and columns 71:198
I=imread('cameraman.pgm');
I=double(I);
image0=I(21:148,71:198);
[nRow, nCol]=size(image0);

% 2D block-DCT and parent-children relationships
BlockSize=8;
[theta0, indiLevel, IdxParent, IdxChildren]=treeDCT2D(image0, BlockSize);

%----------------------------------
% Projection matrix and observation
%----------------------------------

% Generate projection matrix Phi, N x M matrix
N = 5000;    % number of CS measurements
M = length(theta0);
Phi = randn(N,M);
Phi = Phi./repmat(sqrt(sum(Phi.^2,1)),[N,1]);	

% CS observations
v = Phi*theta0;

%----------------------------
% CS inversion by TSDCTCSmcmc
%----------------------------

theta = TSDCTCSvb(Phi, v, indiLevel, IdxParent, IdxChildren);
% "[]" can be used as input arguments for default values, e.g.,
% theta = TSDCTCSvb(Phi, v, indiLevel, IdxParent, IdxChildren, [], [], 1);

%---------------------
% Reconstruction error
% --------------------

image=treeIDCT2D(theta, BlockSize, [nRow, nCol]);
ERR=sqrt(sum(sum((image-image0).^2,1),2)/sum(sum(image0.^2,1),2));

% ----
% plot
% ----

figure, subplot(2,2,1), imagesc(image0); colormap(gray); 
axis square; title('Original Image')
subplot(2,2,2); plot(theta0,'r')
axis([1,M,1.1*min(theta0), 1.1*max(theta0)]); title('Original Sparse Coefficients')
subplot(2,2,3); plot(theta);
axis([1,M,1.1*min(theta0), 1.1*max(theta0)]); title('Reconstructed Sparse Coefficients')
subplot(2,2,4); imagesc(image); colormap(gray);
axis square; title(['Recovered Image, rela err = ',num2str(ERR)])
