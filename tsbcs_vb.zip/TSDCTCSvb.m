function [m_theta, Z, m_W]=TSDCTCSvb(Phi, y, indiLevel, IdxParent, IdxChildren, hyperpara, VBpara, plotflag)
%TSDCTCSvb: Tree-structured CS inversion for block-DCT coefficients implemented by VB.
%USAGE: [theta, Z, W]=TSDCTCSvb(Phi, v, indiLevel, IdxParent, IdxChildren, hyperpara, VBpara, plotflag)
%INPUT (number in [] means default value):  
%   Phi: n x N, CS projection matrix
%   v: n x 1, CS observation
%   indiLevel: N x 1, depth level (in a tree) for each coefficient (zero means DC)  
%   IdxParent: N x 1, parent index. IdxParent(i)=j means the parent of the ith coefficient is coefficient j 
%              Zero means no parent.
%   IdxChildren: N x nChildren, children index. IdxChildren(i,:)=[j(1),...,j(nChildren)] means
%                the children of the ith coefficient are coefficients j(1),...,j(nChildren). 
%                Zeros represent no children.
%   hyperpara: VB hyperparameters
%       hyperpara.a: scalar, hyperparameter 1 for noise precision [1e-6]
%       hyperpara.b: scalar, hyperparameter 2 for noise precision [1e-6]
%       hyperpara.c: scalar, hyperparameter 1 for non-sparse coefficients precision [1e-6] 
%       hyperpara.d: scalar, hyperparameter 2 for non-sparse coefficients precision [1e-6] 
%       hyperpara.es: scalar, hyperparameter 1 for pi of DC coefficients [(1-eps)*Ndc]  
%       hyperpara.fs: scalar, hyperparameter 2 for pi of DC coefficients [eps*Ndc]  
%       hyperpara.er: scalar, hyperparameter 1 for pi of root AC coefficients [0.9*Ns(1)] 
%       hyperpara.fr: scalar, hyperparameter 2 for pi of root AC coefficients [0.1*Ns(1)]  
%       hyperpara.e0: 1 x L, hyperparameters 1 for pi of nonroot AC coefficients with zero parent for each 
%                     depth level. e0(1) is useless, convenient for coding. [ [0, 1/N, ..., 1/N].*Ns ]
%       hyperpara.f0: 1 x L, hyperparameters 2 for pi of nonroot AC coefficients with zero parent for each 
%                     depth level. f0(1) is useless, convenient for coding. [ [0, 1-1/N, ..., 1-1/N].*Ns ]
%       hyperpara.e1: 1 x L, hyperparameters 1 for pi of nonroot AC coefficients with nonzero parent for each 
%                     depth level. e1(1) is useless, convenient for coding. [ [0, 0.5, ..., 0.5].*Ns ]
%       hyperpara.f1: 1 x L, hyperparameters 2 for pi of nonroot AC coefficients with nonzero parent for each 
%                     depth level. f1(1) is useless, convenient for coding. [ [0, 0.5, ..., 0.5].*Ns ]
%       In above default expressions, Ndc denotes the total number of DC coefficients, and Ns(s) for s=1,...,L 
%       denotes the total number of (AC) coefficients at depth level s.
%   VBpara: VB parameters
%       VBpara.maxIter: scalar, maximum number of VB iterations [40]
%       VBpara.tol: tolarance of relative change of VB lower bound for two consecutive steps [1e-4] 
%   plotflag: indicator, one means plotting result for each iteration, zero means no plot [0] 
%OUTPUT:
%   theta: N x 1, mean of reconstructed signal
%   Z: N x 1, mean of zero/one indicators
%   W: N x 1, mean of non-sparse coefficients

%--------------------------------------------------------------------------
% References:
% L.He, H. Chen and L.Carin, "Tree-structured compressive sensing with 
% variational Bayesian Analysis" (2009)  
%
% Originally Written: Haojun Chen, ECE, Duke University, June, 2009
% Modified: Lihan He, ECE, Duke University, July, 2009
% Last Change: Aug. 3, 2009
%--------------------------------------------------------------------------

% ---------------------
% check input arguments
% ---------------------

if nargin<8, plotflag=0; end
if nargin<7
    VBpara.maxIter=40;
    VBpara.tol=1e-4;
end
if nargin<6
    % Number of coefficients
    [n,N]=size(Phi);          % all coefficients
    Ndc=length(find(indiLevel==0));     % DC coefficients
    L=max(indiLevel);       % largest depth
    Ns=zeros(1,L);          % AC coefficients for depths 1:L
    for s=1:L, Ns(s)=length(find(indiLevel==s)); end
    % hyperparameters
    hyperpara.a=1e-6;
    hyperpara.b=1e-6;
    hyperpara.c=2e+9;
    hyperpara.d=1e+10;
    hyperpara.es=(1-eps)*Ndc;
    hyperpara.fs=eps*Ndc;
    hyperpara.er=0.9*Ns(1);
    hyperpara.fr=0.1*Ns(1);
    hyperpara.e0=[0, ones(1, L-1)/N].*Ns;
    hyperpara.f0=[0, 1-ones(1, L-1)/N].*Ns;
    hyperpara.e1=[0, ones(1, L-1)*0.5].*Ns;
    hyperpara.f1=[0, ones(1, L-1)*0.5].*Ns;
end

if isempty(hyperpara)
    % Number of coefficients
    [n,N]=size(Phi);          % all coefficients
    Ndc=length(find(indiLevel==0));     % DC coefficients
    L=max(indiLevel);       % largest depth
    Ns=zeros(1,L);          % AC coefficients for depths 1:L
    for s=1:L, Ns(s)=length(find(indiLevel==s)); end
    % hyperparameters
    hyperpara.a=1e-6;
    hyperpara.b=1e-6;
    hyperpara.c=2e+9;
    hyperpara.d=1e+10;
    hyperpara.es=(1-eps)*Ndc;
    hyperpara.fs=eps*Ndc;
    hyperpara.er=0.9*Ns(1);
    hyperpara.fr=0.1*Ns(1);
    hyperpara.e0=[0, ones(1, L-1)/N].*Ns;
    hyperpara.f0=[0, 1-ones(1, L-1)/N].*Ns;
    hyperpara.e1=[0, ones(1, L-1)*0.5].*Ns;
    hyperpara.f1=[0, ones(1, L-1)*0.5].*Ns;
end
if isempty(VBpara)
    VBpara.maxIter=40;
    VBpara.tol=1e-4;
end
if isempty(plotflag), plotflag=0; end

a0=hyperpara.a;
b0=hyperpara.b;
c0=hyperpara.c;
d0=hyperpara.d;
es0=hyperpara.es;
fs0=hyperpara.fs;
er0=hyperpara.er;
fr0=hyperpara.fr;
e00=hyperpara.e0;
f00=hyperpara.f0;
e10=hyperpara.e1;
f10=hyperpara.f1;

stdY=std(y);
y=y/stdY;

% -------------------
% Data specifications
% -------------------

% Number of measurements and number of coefficients
[n,N]=size(Phi);
% Tree depth
L=max(indiLevel);
% number of children for each parent
Nchildren=size(IdxChildren,2);
% DC coefficients
Ndc=length(find(indiLevel==0));     
% AC coefficients for depths 1:L
Ns=zeros(1,L);          
for s=1:L, Ns(s)=length(find(indiLevel==s)); end

% ------------
%Initialiation
% ------------

% NonzeroIndicator ~ bernoulli(Z)
Z=es0/(es0+fs0)*ones(N,1);
idxLevel0=find(indiLevel==0);
idxLevel{s}=find(indiLevel==1);
Z(idxLevel{s})=er0/(er0+fr0);
for s=2:L
    idxLevel{s}=find(indiLevel==s);
    Z(idxLevel{s})=e00(s)/(e00(s)+f00(s));
end

% W~N(muW, sigmaW)
muW=eps*ones(N,1);
sigmaW=eps*ones(N,1);

muW2=muW.*muW;
EWW=muW2+sigmaW;
ZW=Z.*muW;

% alpha0~Gamma(a,b); a_b=<alpha0>=a/b
a_b=100/stdY^2;

% alpha_s~Gamma(c,d); c_d=<alpha_s>=c/d
c_d=eps*ones(N,1);

% pi~Beta(e,f);
% pai1=psi(e)-psi(e+f), pai2=psi(f)-psi(e+f) for each coefficient
pai1=psi(er0)*ones(N,1);
pai0=psi(fr0)*ones(N,1);

%---------------
% precomputation
%---------------

% Phi_{i}^{T}Phi_{i} for all i, N x 1 vector
diagPhi2=sum(Phi.*Phi,1)';

% ------------
% VB iteration
% ------------

for i=1:VBpara.maxIter

    %Update NonzeroIndicator
    res=y-Phi*ZW;
    for j=1:N
        res=res+Phi(:,j)*ZW(j);
        t1=pai1(j)-0.5*a_b*(EWW(j)*diagPhi2(j) -2*muW(j)*(Phi(:,j)'*res));
        t2=pai0(j);
        Z(j) = 1/(1+exp(t2-t1));
        ZW(j)=Z(j)*muW(j);
        res=res-Phi(:,j)*ZW(j);
    end

    %Update W
    sigmaW=1./(c_d+a_b*(diagPhi2));
    for j=1:N
        res=res+Phi(:,j)*ZW(j);
        muW(j)=sigmaW(j)*(res'*Phi(:,j))*a_b;
        ZW(j)=Z(j)*muW(j);
        res=res-Phi(:,j)*ZW(j);
    end
    muW2=muW.*muW;
    EWW=muW2+sigmaW;

    %Update alpha_0
    a=a0+n/2;
    E=res'*res-(muW2.*Z.^2-EWW.*Z)'*diagPhi2;
    b=b0+0.5*E;
    a_b=a/b;

    %Update alpha_s
    c_d=(c0+Ndc/2)/(d0+sum(EWW(idxLevel0))/2)*ones(Ndc,1);
    for s=1:L
        c(s)=c0+Ns(s)/2;
        d(s)=d0+sum(EWW(idxLevel{s}))/2;
        c_d=[c_d;c(s)/d(s)*ones(Ns(s),1)];
    end

    %Update pi_s
    es=es0+sum(Z(1:Ndc));
    fs=fs0+Ndc-sum(Z(1:Ndc));
    pai1=psi(es)*ones(N,1);
    pai0=psi(fs)*ones(N,1);    

    %Update pi_r
    er=er0+sum(Z(1:Ns(1)));
    fr=fr0+Ns(1)-sum(Z(1:Ns(1)));
    pai1(idxLevel{1})=psi(er);
    pai0(idxLevel{1})=psi(fr);

    %Update pi_0 and pi_1
    for s=2:L
        idx=idxLevel{s};
        e0(s)=e00(s)+sum((1-Z(IdxParent(idx))).*Z(idx));
        f0(s)=f00(s)+sum((1-Z(IdxParent(idx))).*(1-Z(idx)));
        e1(s)=e10(s)+sum(Z(IdxParent(idx)).*Z(idx));
        f1(s)=f10(s)+sum(Z(IdxParent(idx)).*(1-Z(idx)));
        pai1(idx)=(1-Z(IdxParent(idx)))*psi(e0(s))+Z(IdxParent(idx))*psi(e1(s));
        pai0(idx)=(1-Z(IdxParent(idx)))*psi(f0(s))+Z(IdxParent(idx))*psi(f1(s));
    end

    fprintf('Iteration %d.\n',i);

    % plot
    if plotflag
        figure(3000), 
        subplot(3,1,1), plot(ZW*stdY,'.'); axis([0,N+1,1.1*min(ZW*stdY),1.1*max(ZW*stdY)]); 
        title(['Iteration',int2str(i),':  mean inverted signal']);
        subplot(3,1,2), stem((Z),'.'); axis([0,N+1,-0.1,1.1]); title('Probality mean of nonzero')
        subplot(3,1,3), stem(muW*stdY,'.'); axis([0,N+1,1.1*min(muW*stdY),1.1*max(muW*stdY)]);
        title('Mean of nonsparse signal')
        xlabel('Coefficient Index'); 
        pause(0.001);
    end
    
end

m_theta=ZW*stdY;
m_W=muW*stdY;
