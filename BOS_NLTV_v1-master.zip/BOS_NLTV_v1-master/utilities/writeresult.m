function result=writeresult(result,u,time,energy,relmse,psnr_n)
result.Img=u;
result.time=time;
result.energy=energy;
result.relmse=relmse;
result.psnr_n=psnr_n;
